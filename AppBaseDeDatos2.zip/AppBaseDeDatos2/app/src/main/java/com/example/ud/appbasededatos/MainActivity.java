package com.example.ud.appbasededatos;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQuery;
import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    private SQLiteDatabase mydatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        inciarDataBase();
        Log.e(" BD NUMREG", String.valueOf(registros()));
        insertarREG();
        ConsultarTodo();
        ActualizarRegistro();
        ConsultarTodo();
        BorrarRegistro();
        ConsultarTodo();
        borrarTodo();


    }
    private void inciarDataBase(){
        try{
            mydatabase = this.openOrCreateDatabase("myBD",MODE_PRIVATE,null);
            mydatabase.execSQL("CREATE TABLE IF NOT EXISTS PERSONA (ID INT,NOMBRE VARCHAR,EDAD INT ,GENERO INT)");
            Log.e(" BD LOG CREAR","se creo ");
        }
        catch (Exception ex){
            Log.e(" BD LOG ", ex.getMessage());
        }
    }
    private int registros(){
        Cursor Consulta01 =mydatabase.rawQuery("SELECT COUNT (*) FROM PERSONA", null);
        Consulta01.moveToFirst();
        int NUMRegistros =Consulta01.getInt(0);
        Consulta01.close();
        return NUMRegistros;
    }


    private void insertarREG()
    { // String ID = String.valueOf(registros()+1);
       mydatabase.execSQL( "insert into persona (id,nombre,genero,edad) values(1,'felipeB',false ,49 )");
        mydatabase.execSQL( "insert into persona (id,nombre,genero,edad) values(2,'luisa',true,18 )");
        mydatabase.execSQL( "insert into persona (id,nombre,genero,edad) values(3,'javier',false ,26 )");
        mydatabase.execSQL( "insert into persona (id,nombre,genero,edad) values(4,'juan',false ,30 )");
        Log.e(" BD INSREG", " OK");
        Log.e(" BD NUMREG", String.valueOf(registros()));
    }


    private void borrarTodo()
    { // String ID = String.valueOf(registros()+1);
        mydatabase.execSQL( "delete from persona");

        Log.e(" BD BORRAR ", " OK");
        Log.e(" BD NUMREG", String.valueOf(registros()));
    }

    private void ConsultarTodo()
    {

        Cursor Consulta01 =mydatabase.rawQuery("SELECT * FROM PERSONA", null);
        String ID=String.valueOf(registros());
        int nombreINDEX=Consulta01.getColumnIndex("NOMBRE");
        int edadINDEX=Consulta01.getColumnIndex("EDAD");
        int generoINDEX=Consulta01.getColumnIndex("GENERO");
        Log.e(" BD INDICES_"," NOMBREID: \t "+nombreINDEX+" EDADID:\t "+edadINDEX+" GENEROID:\t "+generoINDEX);

        while (Consulta01.moveToNext())
        {            int NUMRegistros =Consulta01.getInt(0);
                  String nombre =Consulta01.getString(nombreINDEX);
                  int edad =Consulta01.getInt(edadINDEX);
                  int genero =Consulta01.getInt(generoINDEX);

            Log.e(" BD INDICES_"," NOMBREBVAL: \t  "+nombre+" EDADVAL:  \t "+edad+"\t GENEROVAL:  \t "+genero);

        }

        Consulta01.close();




        Log.e(" BD NUMREG", String.valueOf(registros()));
    }



    private void ActualizarRegistro(){
        mydatabase.execSQL( "update persona set edad = 45 where id = 1");
        mydatabase.execSQL( "update persona set edad = 45 ,nombre='felipe' where id = 1");


    }

    private void BorrarRegistro(){
        mydatabase.execSQL( "delete from persona  where id = 1");


    }

}